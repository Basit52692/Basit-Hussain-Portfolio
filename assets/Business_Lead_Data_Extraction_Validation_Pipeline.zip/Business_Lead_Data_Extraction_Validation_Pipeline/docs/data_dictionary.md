# Data Dictionary

| Field | Description |
|---|---|
| business_name | Business/listing name |
| category | Business category |
| city | City |
| state | State abbreviation |
| postal_code | Postal / ZIP code |
| address | Street address |
| phone | Normalized phone number |
| email | Contact email when available |
| website | Normalized website URL |
| source | Source page or directory reference |
| scraped_at | Extraction timestamp |
| website_status | Available / Not Available |
| quality_flag | Missing-field or validation notes |
| lead_status | Existing Website / Potential Lead / Needs Review |
| completeness_score | Share of populated core fields (0–1) |
