# Methodology

## 1. Extraction
The bundled demo scraper reads four local HTML pages containing synthetic business listings. This provides a reproducible scraping demonstration without using client or third-party proprietary data.

## 2. Standardization
Whitespace, names, phone numbers, websites, email casing, and state values are normalized.

## 3. Deduplication
Records are deduplicated using normalized business name + phone number. If phone is missing, name + city + category are used.

## 4. Validation
The pipeline checks missing phone, website, address, and basic email structure.

## 5. Classification
- **Potential Lead:** website missing + phone available
- **Existing Website:** website available and no critical review flag
- **Needs Review:** phone or address missing

## 6. Output
The pipeline writes a clean CSV, JSON summary, and a multi-sheet Excel report.
