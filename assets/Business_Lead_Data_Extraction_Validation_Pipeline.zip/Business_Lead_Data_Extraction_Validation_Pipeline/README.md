# Business Lead Data Extraction & Validation Pipeline

A portfolio project that demonstrates an end-to-end **web data collection, cleaning, validation, deduplication, lead classification, and reporting workflow** using Python.

> **Privacy note:** All records in this repository are synthetic demo data. No employer, client, or confidential Q-Solutions data is included.

![Pipeline](assets/pipeline_flow.svg)

## Output Preview

![Excel report preview](assets/report_preview.png)

## Business Problem

Raw business-directory data is often incomplete and duplicated. Names may use inconsistent casing, phone numbers may have different formats, websites can be missing, and records may need manual verification before they are useful for outreach or analysis.

This project turns raw listings into a structured, quality-checked lead dataset.

## Tech Stack

- Python
- pandas
- BeautifulSoup
- Selenium (generic dynamic-directory template)
- Excel / OpenPyXL for local runtime exports
- pytest
- CSV / JSON

## Pipeline

1. **Extract** demo business listings from bundled HTML pages.
2. **Normalize** names, phone numbers, websites, emails, city/state values.
3. **Deduplicate** using normalized business name + phone (fallback: name + city + category).
4. **Validate** missing phone, address, website, and email format.
5. **Classify** website availability and lead status.
6. **Score** record completeness.
7. **Export** clean CSV, JSON summary, and multi-sheet Excel report.

## Verified Demo Results

| Metric | Result |
|---|---:|
| Raw records | 168 |
| Unique records | 150 |
| Duplicates removed | 18 |
| Website available | 91 |
| Website not available | 59 |
| Phone available | 138 |
| Potential leads | 54 |
| Needs review | 18 |

**Potential Lead definition:** website missing + phone available.

## Project Structure

```text
Business_Lead_Data_Extraction_Validation_Pipeline/
├── README.md
├── requirements.txt
├── run_pipeline.py
├── config.example.json
├── src/
│   ├── cleaning.py
│   ├── validation.py
│   ├── reporting.py
│   ├── scraper_bs4.py
│   └── scraper_selenium.py
├── tests/
│   └── test_cleaning.py
├── sample_site/
│   ├── index.html
│   └── page_1.html ... page_4.html
├── data/
│   ├── raw/business_listings_raw.csv
│   └── processed/business_listings_clean.csv
├── outputs/
│   ├── Business_Lead_Report.xlsx
│   └── summary.json
├── docs/
│   ├── data_dictionary.md
│   ├── methodology.md
│   └── ethics_and_privacy.md
└── assets/
    └── pipeline_flow.svg
```

## Run Locally

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
pip install -r requirements.txt
python run_pipeline.py
```

To regenerate the raw CSV from the bundled local HTML pages:

```bash
python run_pipeline.py --scrape-demo
```

Run tests:

```bash
pytest
```

## Excel Output

`outputs/Business_Lead_Report.xlsx` contains:

- **Summary**
- **Clean Leads**
- **Website Available**
- **Website Not Available**
- **Needs Review**

## Selenium Template

`src/scraper_selenium.py` demonstrates how the extraction layer can be adapted for a JavaScript-rendered directory using configurable CSS selectors.

It is intentionally **not hardcoded to Google Maps or any other third-party platform**. Use automation only where permitted and follow site terms, access controls, rate limits, and privacy requirements.

## What This Project Demonstrates

- Practical web-data workflow design
- Data cleaning with pandas
- Duplicate detection
- Missing-value and quality checks
- Lead classification logic
- Reusable Python functions
- Structured outputs for business users
- Responsible handling of scraping and privacy

## Portfolio Positioning

This project complements traditional analyst projects by showing how data can be collected and prepared **before** analysis begins — bridging web data extraction, data quality, automation, and Excel reporting.
