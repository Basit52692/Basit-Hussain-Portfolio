import pandas as pd
from src.cleaning import clean_business_data
from src.validation import enrich_and_validate

def test_duplicate_normalization():
    df = pd.DataFrame([
        {"business_name": "Apex Plumbing", "category": "Plumber", "city": "Seattle", "state": "WA",
         "address": "1 Main St", "phone": "+1-206-555-0100", "website": "", "email": "",
         "postal_code": "98101", "source": "A", "scraped_at": ""},
        {"business_name": "  APEX PLUMBING  ", "category": "Plumber", "city": "Seattle", "state": "WA",
         "address": "1 Main St", "phone": "2065550100", "website": "", "email": "",
         "postal_code": "98101", "source": "B", "scraped_at": ""},
    ])
    clean, removed = clean_business_data(df)
    assert len(clean) == 1
    assert removed == 1

def test_potential_lead_classification():
    df = pd.DataFrame([{
        "business_name": "Demo Electric", "category": "Electrician", "city": "Tacoma", "state": "WA",
        "address": "5 Pine St", "phone": "+1-253-555-0101", "website": "", "email": "",
        "postal_code": "98402", "source": "Demo", "scraped_at": ""
    }])
    clean, _ = clean_business_data(df)
    enriched = enrich_and_validate(clean)
    assert enriched.loc[0, "lead_status"] == "Potential Lead"
