import argparse
import json
from pathlib import Path

import pandas as pd

from src.cleaning import clean_business_data
from src.validation import enrich_and_validate, build_summary
from src.reporting import export_excel_report
from src.scraper_bs4 import scrape_local_demo

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description="Business Lead Data Extraction & Validation Pipeline")
    parser.add_argument(
        "--scrape-demo",
        action="store_true",
        help="Regenerate raw data by scraping the bundled synthetic HTML directory."
    )
    args = parser.parse_args()

    raw_path = ROOT / "data" / "raw" / "business_listings_raw.csv"
    clean_path = ROOT / "data" / "processed" / "business_listings_clean.csv"
    summary_path = ROOT / "outputs" / "summary.json"
    report_path = ROOT / "outputs" / "Business_Lead_Report.xlsx"

    if args.scrape_demo:
        raw_df = scrape_local_demo(ROOT / "sample_site")
        raw_df.to_csv(raw_path, index=False)
    else:
        raw_df = pd.read_csv(raw_path, dtype=str).fillna("")

    clean_df, duplicates_removed = clean_business_data(raw_df)
    clean_df = enrich_and_validate(clean_df)

    clean_df.to_csv(clean_path, index=False)
    summary = build_summary(clean_df, len(raw_df), duplicates_removed)
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    export_excel_report(clean_df, report_path, raw_count=len(raw_df), duplicates_removed=duplicates_removed)

    print("=" * 62)
    print("BUSINESS LEAD DATA PIPELINE")
    print("=" * 62)
    for key, value in summary.items():
        print(f"{key.replace('_', ' ').title():28} {value}")
    print("-" * 62)
    print(f"Clean CSV : {clean_path}")
    print(f"Excel     : {report_path}")
    print("=" * 62)

if __name__ == "__main__":
    main()
