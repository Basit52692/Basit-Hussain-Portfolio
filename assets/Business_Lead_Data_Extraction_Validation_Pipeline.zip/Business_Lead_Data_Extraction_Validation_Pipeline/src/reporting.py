from pathlib import Path

import pandas as pd
from openpyxl import load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEADER_FILL = "17324D"
HEADER_FONT = "FFFFFF"
LIGHT_FILL = "F6F9FC"
RED_FILL = "FDECEC"
GREEN_FILL = "EAF7EE"
AMBER_FILL = "FFF5D6"

def _style_data_sheet(ws):
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    for cell in ws[1]:
        cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
        cell.font = Font(color=HEADER_FONT, bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    widths = {
        1: 28, 2: 18, 3: 14, 4: 8, 5: 12, 6: 26, 7: 18, 8: 28,
        9: 34, 10: 18, 11: 18, 12: 28, 13: 16, 14: 26, 15: 20,
    }
    for idx, width in widths.items():
        ws.column_dimensions[get_column_letter(idx)].width = width

    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

        website_status = row[9].value
        lead_status = row[10].value

        if website_status == "Not Available":
            row[9].fill = PatternFill("solid", fgColor=RED_FILL)
            row[9].font = Font(color="B91C1C", bold=True)

        if lead_status == "Potential Lead":
            row[10].fill = PatternFill("solid", fgColor=GREEN_FILL)
            row[10].font = Font(color="166534", bold=True)
        elif lead_status == "Needs Review":
            row[10].fill = PatternFill("solid", fgColor=AMBER_FILL)
            row[10].font = Font(color="92400E", bold=True)

        row[12].number_format = "0%"

def _style_summary(ws, summary):
    ws.sheet_view.showGridLines = False
    ws.merge_cells("A1:H2")
    ws["A1"] = "BUSINESS LEAD DATA PIPELINE — DEMO REPORT"
    ws["A1"].fill = PatternFill("solid", fgColor="0F2133")
    ws["A1"].font = Font(color="FFFFFF", bold=True, size=18)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")

    ws.merge_cells("A3:H3")
    ws["A3"] = "Synthetic portfolio data · No employer/client records included"
    ws["A3"].fill = PatternFill("solid", fgColor="EAF1F8")
    ws["A3"].font = Font(color="425466", italic=True)
    ws["A3"].alignment = Alignment(horizontal="center")

    kpis = [
        ("Raw Records", summary["raw_records"]),
        ("Unique Records", summary["unique_records"]),
        ("Duplicates Removed", summary["duplicates_removed"]),
        ("Potential Leads", summary["potential_leads"]),
        ("Website Available", summary["website_available"]),
        ("Website Not Available", summary["website_not_available"]),
        ("Phone Available", summary["phone_available"]),
        ("Needs Review", summary["needs_review"]),
    ]
    anchors = ["A5","C5","E5","G5","A9","C9","E9","G9"]
    for (label, value), anchor in zip(kpis, anchors):
        col = ws[anchor].column
        row = ws[anchor].row
        ws.merge_cells(start_row=row, start_column=col, end_row=row+2, end_column=col+1)
        cell = ws.cell(row=row, column=col)
        cell.value = f"{label}\n{value}"
        cell.fill = PatternFill("solid", fgColor=LIGHT_FILL)
        cell.font = Font(color=HEADER_FILL, bold=True, size=14)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws["A13"], ws["B13"] = "Website Status", "Count"
    ws["A14"], ws["B14"] = "Available", summary["website_available"]
    ws["A15"], ws["B15"] = "Not Available", summary["website_not_available"]
    ws["A16"], ws["B16"] = "Total", summary["unique_records"]

    ws["D13"], ws["E13"] = "Lead Status", "Count"
    ws["D14"], ws["E14"] = "Potential Lead", summary["potential_leads"]
    ws["D15"], ws["E15"] = "Needs Review", summary["needs_review"]
    ws["D16"], ws["E16"] = "Other", summary["unique_records"] - summary["potential_leads"] - summary["needs_review"]

    for cell in ws[13]:
        if cell.column in (1,2,4,5):
            cell.fill = PatternFill("solid", fgColor=HEADER_FILL)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center")

    ws.merge_cells("A18:H18")
    ws["A18"] = "Lead Definition"
    ws["A18"].fill = PatternFill("solid", fgColor=HEADER_FILL)
    ws["A18"].font = Font(color="FFFFFF", bold=True)

    ws.merge_cells("A19:H21")
    ws["A19"] = (
        "Potential Lead = website missing + phone available. "
        "Needs Review = phone or address missing. "
        "Completeness score is based on seven core fields."
    )
    ws["A19"].fill = PatternFill("solid", fgColor="F8FAFC")
    ws["A19"].font = Font(color="334155")
    ws["A19"].alignment = Alignment(vertical="center", wrap_text=True)

    chart = BarChart()
    chart.type = "col"
    chart.style = 10
    chart.title = "Website Availability"
    chart.y_axis.title = "Records"
    data = Reference(ws, min_col=2, min_row=13, max_row=15)
    cats = Reference(ws, min_col=1, min_row=14, max_row=15)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 7
    chart.width = 11
    ws.add_chart(chart, "J4")

    for col in range(1, 9):
        ws.column_dimensions[get_column_letter(col)].width = 18

def export_excel_report(df, output_path, raw_count=None, duplicates_removed=0):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    website_available = df[df["website_status"] == "Available"].copy()
    website_missing = df[df["website_status"] == "Not Available"].copy()
    needs_review = df[df["lead_status"] == "Needs Review"].copy()

    summary = {
        "raw_records": int(raw_count if raw_count is not None else len(df) + duplicates_removed),
        "unique_records": int(len(df)),
        "duplicates_removed": int(duplicates_removed),
        "website_available": int(len(website_available)),
        "website_not_available": int(len(website_missing)),
        "phone_available": int((df["phone"].astype(str).str.strip() != "").sum()),
        "potential_leads": int((df["lead_status"] == "Potential Lead").sum()),
        "needs_review": int(len(needs_review)),
    }

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        # Placeholder Summary sheet; styled after write.
        pd.DataFrame([[""]]).to_excel(writer, sheet_name="Summary", index=False, header=False)
        df.to_excel(writer, sheet_name="Clean Leads", index=False)
        website_available.to_excel(writer, sheet_name="Website Available", index=False)
        website_missing.to_excel(writer, sheet_name="Website Not Available", index=False)
        needs_review.to_excel(writer, sheet_name="Needs Review", index=False)

    wb = load_workbook(output_path)
    _style_summary(wb["Summary"], summary)
    for name in ["Clean Leads", "Website Available", "Website Not Available", "Needs Review"]:
        _style_data_sheet(wb[name])
    wb.save(output_path)

    return output_path
