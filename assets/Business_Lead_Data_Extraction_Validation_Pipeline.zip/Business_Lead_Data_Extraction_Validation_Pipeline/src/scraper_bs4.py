from pathlib import Path
from bs4 import BeautifulSoup
import pandas as pd

def text_of(card, selector):
    node = card.select_one(selector)
    return node.get_text(" ", strip=True) if node else ""

def scrape_local_demo(sample_site_dir):
    """Scrape the bundled synthetic HTML pages. No internet connection is required."""
    records = []
    sample_site_dir = Path(sample_site_dir)

    for page in sorted(sample_site_dir.glob("page_*.html")):
        soup = BeautifulSoup(page.read_text(encoding="utf-8"), "html.parser")

        for card in soup.select(".business-card"):
            records.append({
                "business_name": text_of(card, ".business-name"),
                "category": text_of(card, ".category"),
                "city": text_of(card, ".city"),
                "state": text_of(card, ".state"),
                "postal_code": text_of(card, ".postal-code"),
                "address": text_of(card, ".address"),
                "phone": text_of(card, ".phone"),
                "email": text_of(card, ".email"),
                "website": text_of(card, ".website"),
                "source": page.name,
                "scraped_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
            })

    return pd.DataFrame(records)
