import re
import pandas as pd

def is_valid_email(value):
    if not value:
        return True
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value))

def enrich_and_validate(df):
    df = df.copy()

    df["website_status"] = df["website"].apply(
        lambda x: "Available" if str(x).strip() else "Not Available"
    )

    def quality_flags(row):
        flags = []
        if not row["phone"]:
            flags.append("Missing phone")
        if not row["website"]:
            flags.append("Missing website")
        if not row["address"]:
            flags.append("Missing address")
        if row["email"] and not is_valid_email(row["email"]):
            flags.append("Invalid email")
        return "; ".join(flags) if flags else "Complete"

    df["quality_flag"] = df.apply(quality_flags, axis=1)

    def lead_status(row):
        if not row["website"] and row["phone"]:
            return "Potential Lead"
        if not row["phone"] or not row["address"]:
            return "Needs Review"
        return "Existing Website"

    df["lead_status"] = df.apply(lead_status, axis=1)

    core_fields = ["business_name","category","city","state","address","phone","website"]
    df["completeness_score"] = df[core_fields].apply(
        lambda row: round((row.astype(str).str.strip() != "").sum() / len(core_fields), 2),
        axis=1
    )

    return df

def build_summary(df, raw_count, duplicates_removed):
    return {
        "raw_records": int(raw_count),
        "unique_records": int(len(df)),
        "duplicates_removed": int(duplicates_removed),
        "website_available": int((df["website_status"] == "Available").sum()),
        "website_not_available": int((df["website_status"] == "Not Available").sum()),
        "phone_available": int((df["phone"].astype(str).str.strip() != "").sum()),
        "potential_leads": int((df["lead_status"] == "Potential Lead").sum()),
        "needs_review": int((df["lead_status"] == "Needs Review").sum()),
    }
