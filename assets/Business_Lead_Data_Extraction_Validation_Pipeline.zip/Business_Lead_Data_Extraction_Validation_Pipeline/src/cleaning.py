import re
import pandas as pd

CORE_FIELDS = ["business_name", "category", "city", "state", "address", "phone", "website"]

def normalize_space(value):
    if pd.isna(value):
        return ""
    return re.sub(r"\s+", " ", str(value).strip())

def normalize_name(value):
    value = normalize_space(value)
    return value.title() if value else ""

def normalize_phone(value):
    value = normalize_space(value)
    digits = re.sub(r"\D", "", value)
    if not digits:
        return ""
    if len(digits) == 10:
        digits = "1" + digits
    if len(digits) == 11 and digits.startswith("1"):
        return f"+1-{digits[1:4]}-{digits[4:7]}-{digits[7:]}"
    return value

def normalize_website(value):
    value = normalize_space(value)
    if not value:
        return ""
    if value.startswith("www."):
        return "https://" + value
    if not re.match(r"^https?://", value, flags=re.I):
        return "https://" + value
    return value

def normalize_email(value):
    return normalize_space(value).lower()

def build_dedupe_key(row):
    name_key = re.sub(r"[^a-z0-9]", "", row["business_name"].lower())
    phone_key = re.sub(r"\D", "", row["phone"])
    if phone_key:
        return f"{name_key}|{phone_key}"
    return f"{name_key}|{row['city'].lower()}|{row['category'].lower()}"

def clean_business_data(df):
    df = df.copy()

    text_cols = [
        "business_name","category","city","state","postal_code","address",
        "phone","email","website","source","scraped_at"
    ]
    for col in text_cols:
        if col not in df.columns:
            df[col] = ""
        df[col] = df[col].apply(normalize_space)

    df["business_name"] = df["business_name"].apply(normalize_name)
    df["city"] = df["city"].apply(normalize_name)
    df["state"] = df["state"].str.upper()
    df["phone"] = df["phone"].apply(normalize_phone)
    df["website"] = df["website"].apply(normalize_website)
    df["email"] = df["email"].apply(normalize_email)

    df["_dedupe_key"] = df.apply(build_dedupe_key, axis=1)
    before = len(df)
    df = df.drop_duplicates(subset="_dedupe_key", keep="first").copy()
    duplicates_removed = before - len(df)
    df = df.drop(columns="_dedupe_key")

    return df.reset_index(drop=True), duplicates_removed
