"""
Generic Selenium collector template for JavaScript-rendered business directories.

This module is intentionally NOT hardcoded to Google Maps or any third-party
website. Configure it only for websites you are permitted to automate and
respect robots.txt, site terms, rate limits, and applicable privacy laws.
"""

from dataclasses import dataclass
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@dataclass
class DirectorySelectors:
    card: str
    business_name: str
    category: str
    city: str
    phone: str
    website: str

def _safe_text(card, selector):
    try:
        return card.find_element(By.CSS_SELECTOR, selector).text.strip()
    except Exception:
        return ""

def scrape_dynamic_directory(url, selectors: DirectorySelectors, timeout=20):
    options = webdriver.ChromeOptions()
    options.add_argument("--headless=new")
    options.add_argument("--disable-notifications")
    driver = webdriver.Chrome(options=options)

    try:
        driver.get(url)
        WebDriverWait(driver, timeout).until(
            EC.presence_of_all_elements_located((By.CSS_SELECTOR, selectors.card))
        )

        records = []
        for card in driver.find_elements(By.CSS_SELECTOR, selectors.card):
            website = ""
            try:
                website = card.find_element(By.CSS_SELECTOR, selectors.website).get_attribute("href") or ""
            except Exception:
                pass

            records.append({
                "business_name": _safe_text(card, selectors.business_name),
                "category": _safe_text(card, selectors.category),
                "city": _safe_text(card, selectors.city),
                "state": "",
                "postal_code": "",
                "address": "",
                "phone": _safe_text(card, selectors.phone),
                "email": "",
                "website": website,
                "source": url,
            })

        return records
    finally:
        driver.quit()
